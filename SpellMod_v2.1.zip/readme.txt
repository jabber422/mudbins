
Spell Mod v2.1 (08/08/2021)
-------------------------
by Demosthenes, Syntax, and Kraklaha

Details: https://www.mudinfo.net/viewtopic.php?f=47&t=1479

** This package includes a slimmed down update from Kraklaha which 
created copies of the original spells for the monsters that cast them.
These spells are #s 5000 through 5039.  Also included are the 110
monsters that cast those spells. Monsters are stock exp, drops, etc.

** new since the original spell mod patch are 3 more spells (5040 
through 5042) that are copies of the originals and 2 additional mobs 
that are fixed.

** For mages we changed the detect magic spell from a worthless
spellbook slot to a somewhat useful magic resistance spell.
This spell is called 'protective aura' (prot) and uses one
of the druids blesses for it's status message (wont conflict
and no new message to import).  You will need to either import
the included scroll (a renamed scroll of detect magic) or change
the name manually to scroll of protective aura.